import cv2
import numpy as np
import matplotlib.pyplot as plt


def convolve(image, kernel):
    """
    使用嵌套 for 循环完成二维卷积。

    参数：
        image  : 二维灰度图像
        kernel : 二维卷积核

    返回：
        result : 卷积后的图像
    """

    # 转换为浮点数，避免 uint8 在减法、负数运算时溢出
    image = image.astype(np.float32)
    kernel = np.array(kernel, dtype=np.float32)

    image_h, image_w = image.shape
    kernel_h, kernel_w = kernel.shape

    # 合法卷积尺寸：卷积核必须完全位于图像内部
    output_h = image_h - kernel_h + 1
    output_w = image_w - kernel_w + 1

    result = np.zeros((output_h, output_w), dtype=np.float32)

    """ TODO: 完成此处的嵌套循环，根据卷积核计算公式得到特征图像素 """

    """ TODO 结束 """

    return result


def prepare_for_display(result, mode="normal"):
    """
    将卷积结果转换到适合 matplotlib 显示的 0~255 范围。
    """

    if mode == "edge":
        # 边缘卷积结果可能同时含正数和负数
        result = np.abs(result)

    # 限制到图像正常灰度范围
    result = np.clip(result, 0, 255)

    return result.astype(np.uint8)


# ============================================================
# 1. 读取图像
# ============================================================

image = cv2.imread(
    "image.jpg",
    cv2.IMREAD_GRAYSCALE
)

if image is None:
    raise FileNotFoundError(
        "没有找到 image.jpg，请将图片放在程序所在目录。"
    )


# 为避免原始图片过大，使实验运行时间过长
image = cv2.resize(image, (256, 256))


# ============================================================
# 2. 定义卷积核
# ============================================================

kernels = {

    # 1. 均值模糊
    "Mean Blur": (
        [
            [1 / 9, 1 / 9, 1 / 9],
            [1 / 9, 1 / 9, 1 / 9],
            [1 / 9, 1 / 9, 1 / 9]
        ],
        "normal"
    ),

    # 2. 高斯模糊
    "Gaussian Blur": (
        [
            [1 / 16, 2 / 16, 1 / 16],
            [2 / 16, 4 / 16, 2 / 16],
            [1 / 16, 2 / 16, 1 / 16]
        ],
        "normal"
    ),

    # 3. 锐化
    "Sharpen": (
        [
            [0, -1, 0],
            [-1, 5, -1],
            [0, -1, 0]
        ],
        "normal"
    ),

    # 4. Laplacian 边缘检测
    "Edge Detection": (
        [
            [0, -1, 0],
            [-1, 4, -1],
            [0, -1, 0]
        ],
        "edge"
    ),
}


# ============================================================
# 3. 对图像分别执行不同卷积
# ============================================================

results = {}

for name, (kernel, mode) in kernels.items():

    result = convolve(image, kernel)

    result = prepare_for_display(
        result,
        mode
    )

    results[name] = result


# ============================================================
# 4. 显示结果
# ============================================================

fig = plt.figure(figsize=(12, 7))

# 创建 2 行 3 列布局
gs = fig.add_gridspec(
    2, 3,
    width_ratios=[1.2, 1, 1],
    wspace=0.08,
    hspace=0.12
)


# -------------------------
# 原始图像：占据左侧两行
# -------------------------

ax_original = fig.add_subplot(gs[:, 0])

ax_original.imshow(
    image,
    cmap="gray",
    vmin=0,
    vmax=255
)

ax_original.set_title(
    "Original Image",
    fontsize=14
)

ax_original.axis("off")


# -------------------------
# 四种卷积结果
# -------------------------

positions = [
    gs[0, 1],
    gs[0, 2],
    gs[1, 1],
    gs[1, 2]
]


for (name, result), position in zip(
    results.items(),
    positions
):

    ax = fig.add_subplot(position)

    ax.imshow(
        result,
        cmap="gray",
        vmin=0,
        vmax=255
    )

    ax.set_title(
        name,
        fontsize=12
    )

    ax.axis("off")


plt.show()